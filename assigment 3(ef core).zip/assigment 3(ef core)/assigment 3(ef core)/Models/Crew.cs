using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace assigment_3_ef_core_.Models
{
    public class Crew
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(100)]
        public string? MajorPilot { get; set; }

        [MaxLength(100)]
        public string? AssistantPilot { get; set; }

        [MaxLength(100)]
        public string? Host1 { get; set; }

        [MaxLength(100)]
        public string? Host2 { get; set; }

        // Foreign Key for Aircraft (One-to-One Required from both sides)
        [Required]
        public int AircraftId { get; set; }

        // Navigation Property
        [ForeignKey("AircraftId")]
        public virtual Aircraft Aircraft { get; set; } = null!;
    }
}
