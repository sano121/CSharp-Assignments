﻿namespace assigment_5;

class Program
    {
        static void PassValueByValue(int x)
        {
            x = x + 10;
            Console.WriteLine("Inside method (by value): " + x);
        }

        static void PassValueByReference(ref int x)
        {
            x = x + 10;
            Console.WriteLine("Inside method (by reference): " + x);
        }

        static void PassReferenceByValue(string str)
        {
            str = "Changed inside method";
            Console.WriteLine("Inside method (by value): " + str);
        }

        
        static void PassReferenceByReference(ref string str)
        {
            str = "Changed inside method";
            Console.WriteLine("Inside method (by reference): " + str);
        }

        
        static (int, int) SumAndSubtract(int a, int b, int c, int d)
        {
            int sum = a + b + c + d;
            int subtract = a - b - c - d;
            return (sum, subtract);
        }

       
        static int SumOfDigits(int number)
        {
            int sum = 0;
            while (number > 0)
            {
                sum += number % 10;
                number /= 10;
            }
            return sum;
        }

       
        static bool IsPrime(int number)
        {
            if (number <= 1) return false;
            for (int i = 2; i <= Math.Sqrt(number); i++)
            {
                if (number % i == 0) return false;
            }
            return true;
        }

       
        static void MinMaxArray(int[] arr, out int min, out int max)
        {
            min = arr[0];
            max = arr[0];
            foreach (int num in arr)
            {
                if (num < min) min = num;
                if (num > max) max = num;
            }
        }

       
        static int FactorialIterative(int n)
        {
            int result = 1;
            for (int i = 2; i <= n; i++)
            {
                result *= i;
            }
            return result;
        }

        
        static string ChangeChar(string str, int position, char newChar)
        {
            if (position < 0 || position >= str.Length) return str;
            char[] chars = str.ToCharArray();
            chars[position] = newChar;
            return new string(chars);
        }

        
        static int Power(int baseNum, int exponent)
        {
            int result = 1;
            for (int i = 0; i < exponent; i++)
            {
                result *= baseNum;
            }
            return result;
        }

        
        static int[] MergeArrays(int[] arr1, int[] arr2)
        {
            int[] merged = new int[arr1.Length + arr2.Length];
            int i = 0, j = 0, k = 0;

            while (i < arr1.Length && j < arr2.Length)
            {
                if (arr1[i] < arr2[j])
                    merged[k++] = arr1[i++];
                else
                    merged[k++] = arr2[j++];
            }

            while (i < arr1.Length) merged[k++] = arr1[i++];
            while (j < arr2.Length) merged[k++] = arr2[j++];

            return merged;
        }

        
        static int[] ReverseArray(int[] arr)
        {
            int[] reversed = new int[arr.Length];
            for (int i = 0; i < arr.Length; i++)
            {
                reversed[i] = arr[arr.Length - 1 - i];
            }
            return reversed;
        }

    
        static int SumNumbers(params int[] numbers)
        {
            int sum = 0;
            foreach (int num in numbers)
            {
                sum += num;
            }
            return sum;
        }

       

        static void Main(string[] args)
        {
            
        }
    }

