using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace assigment_3_ef_core_.Models
{
    // Many-to-Many Join Table: Aircraft <-> Route
    public class AircraftRoute
    {
        [Key]
        public int Id { get; set; }

        // Foreign Keys
        [Required]
        public int AircraftId { get; set; }

        [Required]
        public int RouteId { get; set; }

        // Additional properties for the relationship
        public int? NumOfPassengers { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? Price { get; set; }

        public DateTime? Arrival { get; set; }

        public DateTime? Departure { get; set; }

        public int? Duration { get; set; } // Duration in hours

        // Navigation Properties
        [ForeignKey("AircraftId")]
        public virtual Aircraft Aircraft { get; set; } = null!;

        [ForeignKey("RouteId")]
        public virtual Route Route { get; set; } = null!;
    }
}
