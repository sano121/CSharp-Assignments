using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace assigment_3_ef_core_.Models
{
    public class Airline
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [MaxLength(100)]
        public string? ContactPerson { get; set; }

        [MaxLength(500)]
        public string? Address { get; set; }

        // Phones as a collection (complex type)
        public List<string> Phones { get; set; } = new List<string>();

        // Navigation Properties

        // One-to-Many: Airline -> Employees (Optional from both sides)
        public virtual ICollection<Employee> Employees { get; set; } = new List<Employee>();

        // One-to-Many: Airline -> Transactions (Optional from both sides)
        [InverseProperty("Airline")]
        public virtual ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();

        // One-to-Many: Airline -> Aircraft (Optional from both sides)
        public virtual ICollection<Aircraft> Aircrafts { get; set; } = new List<Aircraft>();
    }
}
