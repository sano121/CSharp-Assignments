using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace assigment_3_ef_core_.Models
{
    public class Aircraft
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Model { get; set; } = string.Empty;

        public int Capacity { get; set; }

        // Foreign Key for Airline (Many-to-One Optional)
        public int? AirlineId { get; set; }

        // Navigation Property
        [ForeignKey("AirlineId")]
        public virtual Airline? Airline { get; set; }

        // One-to-One: Aircraft -> Crew (Required from both sides)
        public virtual Crew? Crew { get; set; }

        // Many-to-Many: Aircraft -> Routes through AircraftRoute
        public virtual ICollection<AircraftRoute> AircraftRoutes { get; set; } = new List<AircraftRoute>();
    }
}
