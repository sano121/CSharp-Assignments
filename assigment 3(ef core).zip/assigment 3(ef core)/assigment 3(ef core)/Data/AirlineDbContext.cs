using Microsoft.EntityFrameworkCore;
using assigment_3_ef_core_.Models;

namespace assigment_3_ef_core_.Data
{
    public class AirlineDbContext : DbContext
    {
        public DbSet<Airline> Airlines { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Transaction> Transactions { get; set; }
        public DbSet<Aircraft> Aircrafts { get; set; }
        public DbSet<Crew> Crews { get; set; }
        public DbSet<Route> Routes { get; set; }
        public DbSet<AircraftRoute> AircraftRoutes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=AirlineDb;Trusted_Connection=True;MultipleActiveResultSets=true");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // ===================================================================
            // FLUENT API CONFIGURATIONS
            // ===================================================================

            // -----------------------------------------------------------------
            // 1. Airline Entity Configuration
            // -----------------------------------------------------------------
            modelBuilder.Entity<Airline>(entity =>
            {
                entity.HasKey(a => a.Id);
                
                entity.Property(a => a.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(a => a.ContactPerson)
                    .HasMaxLength(100);

                entity.Property(a => a.Address)
                    .HasMaxLength(500);

                // Complex type: Phones (stored as JSON in EF Core 9)
                entity.Property(a => a.Phones)
                    .HasColumnType("nvarchar(max)");

                // One-to-Many: Airline -> Employees (Optional from both sides)
                entity.HasMany(a => a.Employees)
                    .WithOne(e => e.Airline)
                    .HasForeignKey(e => e.AirlineId)
                    .OnDelete(DeleteBehavior.SetNull); // Optional relationship

                // One-to-Many: Airline -> Transactions (Optional from both sides)
                entity.HasMany(a => a.Transactions)
                    .WithOne(t => t.Airline)
                    .HasForeignKey(t => t.AirlineId)
                    .OnDelete(DeleteBehavior.SetNull); // Optional relationship

                // One-to-Many: Airline -> Aircraft (Optional from both sides)
                entity.HasMany(a => a.Aircrafts)
                    .WithOne(ac => ac.Airline)
                    .HasForeignKey(ac => ac.AirlineId)
                    .OnDelete(DeleteBehavior.SetNull); // Optional relationship
            });

            // -----------------------------------------------------------------
            // 2. Employee Entity Configuration
            // -----------------------------------------------------------------
            modelBuilder.Entity<Employee>(entity =>
            {
                entity.HasKey(e => e.Id);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Position)
                    .HasMaxLength(100);

                entity.Property(e => e.Gender)
                    .HasMaxLength(10);

                entity.Property(e => e.Address)
                    .HasMaxLength(500);

                entity.Property(e => e.Qualifications)
                    .HasMaxLength(500);

                // Foreign key configuration is already done in Airline entity
            });

            // -----------------------------------------------------------------
            // 3. Transaction Entity Configuration
            // -----------------------------------------------------------------
            modelBuilder.Entity<Transaction>(entity =>
            {
                entity.HasKey(t => t.Id);

                entity.Property(t => t.Description)
                    .HasMaxLength(500);

                entity.Property(t => t.Amount)
                    .HasColumnType("decimal(18,2)");

                entity.Property(t => t.Date)
                    .HasColumnType("datetime2");

                // Foreign key configuration is already done in Airline entity
            });

            // -----------------------------------------------------------------
            // 4. Aircraft Entity Configuration
            // -----------------------------------------------------------------
            modelBuilder.Entity<Aircraft>(entity =>
            {
                entity.HasKey(a => a.Id);

                entity.Property(a => a.Model)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(a => a.Capacity)
                    .IsRequired();

                // One-to-One: Aircraft -> Crew (Required from both sides)
                entity.HasOne(a => a.Crew)
                    .WithOne(c => c.Aircraft)
                    .HasForeignKey<Crew>(c => c.AircraftId)
                    .OnDelete(DeleteBehavior.Cascade); // Required relationship
            });

            // -----------------------------------------------------------------
            // 5. Crew Entity Configuration
            // -----------------------------------------------------------------
            modelBuilder.Entity<Crew>(entity =>
            {
                entity.HasKey(c => c.Id);

                entity.Property(c => c.MajorPilot)
                    .HasMaxLength(100);

                entity.Property(c => c.AssistantPilot)
                    .HasMaxLength(100);

                entity.Property(c => c.Host1)
                    .HasMaxLength(100);

                entity.Property(c => c.Host2)
                    .HasMaxLength(100);

                // Foreign key configuration is already done in Aircraft entity
            });

            // -----------------------------------------------------------------
            // 6. Route Entity Configuration
            // -----------------------------------------------------------------
            modelBuilder.Entity<Route>(entity =>
            {
                entity.HasKey(r => r.Id);

                entity.Property(r => r.Origin)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(r => r.Destination)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(r => r.Classification)
                    .HasMaxLength(50);

                entity.Property(r => r.Distance)
                    .IsRequired();
            });

            // -----------------------------------------------------------------
            // 7. AircraftRoute Entity Configuration (Many-to-Many Join Table)
            // -----------------------------------------------------------------
            modelBuilder.Entity<AircraftRoute>(entity =>
            {
                entity.HasKey(ar => ar.Id);

                entity.Property(ar => ar.Price)
                    .HasColumnType("decimal(18,2)");

                entity.Property(ar => ar.Arrival)
                    .HasColumnType("datetime2");

                entity.Property(ar => ar.Departure)
                    .HasColumnType("datetime2");

                // Many-to-Many: Aircraft <-> Route
                entity.HasOne(ar => ar.Aircraft)
                    .WithMany(a => a.AircraftRoutes)
                    .HasForeignKey(ar => ar.AircraftId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(ar => ar.Route)
                    .WithMany(r => r.AircraftRoutes)
                    .HasForeignKey(ar => ar.RouteId)
                    .OnDelete(DeleteBehavior.Cascade);

                // Composite unique index to prevent duplicate assignments
                entity.HasIndex(ar => new { ar.AircraftId, ar.RouteId })
                    .IsUnique();
            });
        }
    }
}
