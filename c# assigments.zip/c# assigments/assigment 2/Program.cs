﻿using System.Text;

namespace assigment_2;

class Program
{
    static void Main(string[] args)
    {
        byte b = 1;            // Value type, 1 byte, range: 0 to 255
        sbyte sb = -1;         // Value type, 1 byte, range: -128 to 127
        short s = 100;         // Value type, 2 bytes, range: -32,768 to 32,767
        ushort us = 200;       // Value type, 2 bytes, range: 0 to 65,535
        int i = 1000;          // Value type, 4 bytes, range: -2,147,483,648 to 2,147,483,647
        uint ui = 1000U;       // Value type, 4 bytes, range: 0 to 4,294,967,295
        long l = 10000L;       // Value type, 8 bytes
        ulong ul = 10000UL;    // Value type, 8 bytes
        float f = 10.5f;       // Value type, 4 bytes, ~7 digits precision
        double d = 20.5;       // Value type, 8 bytes, ~15-16 digits precision
        decimal dec = 100.25m; // Value type, 16 bytes, high precision for financial calculations
        char c = 'A';          // Value type, 2 bytes (Unicode character)
        bool flag = true;      // Value type, size is 1 byte (commonly treated as 1)

        string str = "Hello";  // Reference type, size depends on length (each char = 2 bytes + object overhead)
        object obj = new object(); // Reference type, base type for all .NET objects, 4/8 bytes reference (32/64-bit)

        //code segmaent store the code ,metadata  store classes wa m3lomat 3n el code static/glodbal de feha el static/cons values
        //value types de byet5zno fe stack
        //reference types de byet5zno fe heap 
        Manager m1 = new Manager { Name = "Ahmed", Id = 1, Age = 35, Salary = 10000 };
        Manager m2 = new Manager { Name = "Sara", Id = 2, Age = 29, Salary = 12000 };
        Manager m3 = new Manager { Name = "Omar", Id = 3, Age = 40, Salary = 15000 };

        // Print them
        Console.WriteLine($"Name: {m1.Name}, Id: {m1.Id}, Age: {m1.Age}, Salary: {m1.Salary}");
        Console.WriteLine($"Name: {m2.Name}, Id: {m2.Id}, Age: {m2.Age}, Salary: {m2.Salary}");
        Console.WriteLine($"Name: {m3.Name}, Id: {m3.Id}, Age: {m3.Age}, Salary: {m3.Salary}");
        string s1 = "Hello";
        string s2 = "Hello";
        string s3 = new string("Hello".ToCharArray());

        Console.WriteLine(Object.ReferenceEquals(s1, s2)); // True (same pool reference)
        Console.WriteLine(Object.ReferenceEquals(s1, s3)); // False (different object)

        String immutable = "arsany";
        StringBuilder mutable = new StringBuilder();
        mutable.Append("arsany mutable");

        int x = 5;
        string s13 = "text";
        Manager m = new Manager();

        Console.WriteLine(x.GetType());
        Console.WriteLine(s13.GetType());
        Console.WriteLine(m.GetType());

        m.dispaly(123);
        m.dispaly("arsany");
        m.dispaly("true");

        m.diplaygenaric(123);
        m.diplaygenaric("arsany");
        m.diplaygenaric(true);

        int a = 10;
        object boxing = a;
        int unboxing = (int)boxing;

        //== → compares references (for objects).

        //Equals → can be overridden to compare content.

        Manager m5 = new Manager { Name = "A", Id = 1, Age = 30, Salary = 1000 };
        Manager m4 = new Manager { Name = "A", Id = 1, Age = 30, Salary = 1000 };
        Console.WriteLine(m5.Equals(m4)); // False (different references)

       

    //Encryption: reversible, used for confidentiality (e.g., AES).
    //Hashing: one-way, used for data integrity (e.g., SHA256).
    ///
    /// Used in hash-based collections (Dictionary, HashSet).
    //Needed because Equals only checks equality, but hash tables need hash buckets.

    }
    class Manager
    {
        public string Name;
        public int Id;
        public int Age;
        public double Salary;

        public void dispaly(Object name)
        {
            Console.WriteLine($"Name: {name}");
        }

        public void diplaygenaric<t>(t var)
        {
            Console.WriteLine($"Name: {var}");
        }

        public override string ToString()
        {
            return $"Name: {Name}, Id: {Id}, Age: {Age}, Salary: {Salary}";
        }

        public override bool Equals(object obj)
        {
            if (obj is Manager other)
                return Name == other.Name && Id == other.Id && Age == other.Age && Salary == other.Salary;
            return false;
        }
        public override int GetHashCode()
        {
            return HashCode.Combine(Name, Id, Age, Salary);
        }
    }
    #region Page4
    
    #endregion

    #region Page5
    
    #endregion


    

}
