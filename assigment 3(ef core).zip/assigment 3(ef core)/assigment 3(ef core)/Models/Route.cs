using System.ComponentModel.DataAnnotations;

namespace assigment_3_ef_core_.Models
{
    public class Route
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Origin { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string Destination { get; set; } = string.Empty;

        [MaxLength(50)]
        public string? Classification { get; set; }

        public int Distance { get; set; }

        // Many-to-Many: Routes -> Aircraft through AircraftRoute
        public virtual ICollection<AircraftRoute> AircraftRoutes { get; set; } = new List<AircraftRoute>();
    }
}
