# EF Core Relationship Implementation - Quick Reference Guide

## Three Ways to Define Relationships in EF Core

### 1. CONVENTION (Automatic Detection)

EF Core automatically detects relationships based on naming conventions and navigation properties.

**Example: One-to-Many (Airline ? Employees)**
```csharp
// No attributes or configuration needed!
public class Airline
{
    public int Id { get; set; }
    public string Name { get; set; }
    public ICollection<Employee> Employees { get; set; } // Collection navigation
}

public class Employee
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int? AirlineId { get; set; } // FK by convention (ClassName + Id)
    public Airline? Airline { get; set; } // Reference navigation
}
```
**EF Core automatically:**
- Recognizes `AirlineId` as foreign key
- Creates one-to-many relationship
- Makes it optional (nullable `int?`)

---

### 2. DATA ANNOTATIONS (Attribute-Based)

Use attributes on properties to explicitly define relationships.

**Example: One-to-One (Aircraft ? Crew)**
```csharp
public class Aircraft
{
    [Key]
    public int Id { get; set; }
    
    public Crew? Crew { get; set; }
}

public class Crew
{
    [Key]
    public int Id { get; set; }
    
    [Required] // Makes relationship required
    public int AircraftId { get; set; }
    
    [ForeignKey("AircraftId")] // Explicitly specifies FK
    public Aircraft Aircraft { get; set; }
}
```

**Common Annotations:**
- `[Key]` - Primary key
- `[Required]` - Non-nullable, required field
- `[ForeignKey("PropertyName")]` - Specifies FK property
- `[InverseProperty("PropertyName")]` - Clarifies navigation property
- `[MaxLength(100)]` - String length constraint
- `[Column(TypeName = "decimal(18,2)")]` - Column type

**Example: One-to-Many with InverseProperty**
```csharp
public class Airline
{
    public int Id { get; set; }
    
    [InverseProperty("Airline")] // Clarifies which navigation to use
    public ICollection<Transaction> Transactions { get; set; }
}

public class Transaction
{
    public int Id { get; set; }
    public int? AirlineId { get; set; }
    
    [ForeignKey("AirlineId")]
    [InverseProperty("Transactions")] // Matches collection name
    public Airline? Airline { get; set; }
}
```

---

### 3. FLUENT API (Method-Based Configuration)

Configure relationships in `OnModelCreating` method of DbContext.

**Example: One-to-One (Required)**
```csharp
protected override void OnModelCreating(ModelBuilder modelBuilder)
{
    modelBuilder.Entity<Aircraft>()
        .HasOne(a => a.Crew)           // Aircraft has one Crew
        .WithOne(c => c.Aircraft)      // Crew has one Aircraft
        .HasForeignKey<Crew>(c => c.AircraftId)  // FK is in Crew table
        .OnDelete(DeleteBehavior.Cascade);        // Delete behavior
}
```

**Example: One-to-Many (Optional)**
```csharp
modelBuilder.Entity<Airline>()
    .HasMany(a => a.Employees)          // Airline has many Employees
    .WithOne(e => e.Airline)            // Employee has one Airline
    .HasForeignKey(e => e.AirlineId)    // FK property
    .OnDelete(DeleteBehavior.SetNull);  // Set FK to null on delete
```

**Example: Many-to-Many (with Join Entity)**
```csharp
// Configure the join entity
modelBuilder.Entity<AircraftRoute>()
    .HasKey(ar => ar.Id);

// Aircraft side
modelBuilder.Entity<AircraftRoute>()
    .HasOne(ar => ar.Aircraft)
    .WithMany(a => a.AircraftRoutes)
    .HasForeignKey(ar => ar.AircraftId)
    .OnDelete(DeleteBehavior.Cascade);

// Route side
modelBuilder.Entity<AircraftRoute>()
    .HasOne(ar => ar.Route)
    .WithMany(r => r.AircraftRoutes)
    .HasForeignKey(ar => ar.RouteId)
    .OnDelete(DeleteBehavior.Cascade);

// Prevent duplicate assignments
modelBuilder.Entity<AircraftRoute>()
    .HasIndex(ar => new { ar.AircraftId, ar.RouteId })
    .IsUnique();
```

**Common Fluent API Methods:**
- `HasOne()` / `HasMany()` - Define relationship
- `WithOne()` / `WithMany()` - Define inverse relationship
- `HasForeignKey()` - Specify FK property
- `IsRequired()` / `IsOptional()` - Nullability
- `OnDelete()` - Delete behavior
- `HasIndex()` - Create index
- `IsUnique()` - Unique constraint

---

## Comparison Table

| Feature | Convention | Data Annotations | Fluent API |
|---------|-----------|------------------|------------|
| **Ease of Use** | ? Easiest | ?? Moderate | ?? Complex |
| **Readability** | ? Clean models | ?? Cluttered models | ? Separated concerns |
| **Flexibility** | ? Limited | ?? Moderate | ? Maximum |
| **Location** | Properties only | In entity classes | In DbContext |
| **Override Convention** | ? No | ? Yes | ? Yes |
| **Complex Scenarios** | ? Not supported | ?? Limited | ? Full support |
| **Delete Behavior** | ? Default only | ? Not configurable | ? Full control |
| **Composite Keys** | ? No | ?? Limited | ? Yes |
| **Multiple Relationships** | ? Ambiguous | ?? Needs InverseProperty | ? Clear |

---

## When to Use Each Approach?

### Use CONVENTION when:
- ? Simple relationships
- ? Following EF Core naming conventions
- ? Want minimal code
- ? Standard scenarios (e.g., BlogId for Blog FK)

### Use DATA ANNOTATIONS when:
- ? Need validation attributes
- ? Simple FK override
- ? Want constraints in entity classes
- ? Code-first migrations
- ?? Avoid for complex relationships

### Use FLUENT API when:
- ? Complex relationships
- ? Custom delete behaviors
- ? Composite keys or indexes
- ? Many-to-many with payload
- ? Multiple relationships between same entities
- ? Non-standard FK names
- ? Need maximum control

---

## Best Practice: Hybrid Approach

**Use a combination:**
1. **Convention** - Let EF Core handle what it can
2. **Data Annotations** - For simple validation and constraints
3. **Fluent API** - For complex relationships and behaviors

**Example:**
```csharp
// Entity (Data Annotations for validation)
public class Employee
{
    [Key]
    public int Id { get; set; }
    
    [Required]
    [MaxLength(100)]
    public string Name { get; set; }
    
    public int? AirlineId { get; set; } // Convention
    public Airline? Airline { get; set; }
}

// DbContext (Fluent API for relationship details)
protected override void OnModelCreating(ModelBuilder modelBuilder)
{
    modelBuilder.Entity<Airline>()
        .HasMany(a => a.Employees)
        .WithOne(e => e.Airline)
        .HasForeignKey(e => e.AirlineId)
        .OnDelete(DeleteBehavior.SetNull); // Custom delete behavior
}
```

---

## Delete Behaviors

| Behavior | Description | Use Case |
|----------|-------------|----------|
| `Cascade` | Delete related entities | Required relationships |
| `SetNull` | Set FK to null | Optional relationships |
| `Restrict` | Prevent deletion if related entities exist | Reference data |
| `NoAction` | Database handles it | Custom DB constraints |

---

## Common Patterns in This Assignment

### 1. One-to-One Required (Aircraft ? Crew)
```csharp
// Convention: Partial ?
// Data Annotations: ?
// Fluent API: ? (Best)
// InverseProperty: Optional
```

### 2. One-to-Many Optional (Airline ? Employees)
```csharp
// Convention: ? Full support
// Data Annotations: ?
// Fluent API: ?
// InverseProperty: When multiple relationships exist
```

### 3. Many-to-Many with Payload (Aircraft ? Routes)
```csharp
// Convention: ? (needs explicit join entity)
// Data Annotations: ?
// Fluent API: ? (Best)
// InverseProperty: Not needed
```

---

## InverseProperty Usage

**When to use:**
- Multiple relationships between same entities
- Clarify which navigation property maps to which

**Example:**
```csharp
public class Airline
{
    [InverseProperty("Airline")]
    public ICollection<Employee> Employees { get; set; }
    
    [InverseProperty("Airline")]
    public ICollection<Transaction> Transactions { get; set; }
    
    [InverseProperty("Airline")]
    public ICollection<Aircraft> Aircrafts { get; set; }
}
```

**Without InverseProperty, this would be ambiguous if there were multiple `Airline` properties in the related entities.**

---

## Summary

| Relationship Type | Best Implementation Method |
|-------------------|---------------------------|
| Simple 1-to-Many | Convention |
| 1-to-1 Required | Fluent API |
| 1-to-Many Optional with custom delete | Fluent API |
| Many-to-Many without payload | Convention (EF Core 5+) |
| Many-to-Many with payload | Fluent API + Join Entity |
| Multiple relationships same entities | Fluent API + InverseProperty |

---

**Remember:** The assignment requires implementing relationships in all three ways to demonstrate understanding. In real projects, choose the most appropriate method for each scenario!
