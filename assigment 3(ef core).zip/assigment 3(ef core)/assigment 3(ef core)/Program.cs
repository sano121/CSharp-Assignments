﻿using assigment_3_ef_core_.Data;
using assigment_3_ef_core_.Models;
using Microsoft.EntityFrameworkCore;

namespace assigment_3_ef_core_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Airline Management System - EF Core Assignment\n");

            using (var context = new AirlineDbContext())
            {
                context.Database.EnsureCreated();
                Console.WriteLine("Database created successfully\n");


                Console.WriteLine("1. Inserting new airline EgyptAir");
                var egyptAir = new Airline
                {
                    Name = "EgyptAir",
                    ContactPerson = "Ahmed Ali",
                    Address = "Cairo",
                    Phones = new List<string> { "0123456789", "0113654789" }
                };
                context.Airlines.Add(egyptAir);
                context.SaveChanges();
                Console.WriteLine("   EgyptAir added with ID: {0}\n", egyptAir.Id);

                Console.WriteLine("2. Adding aircraft Model01 to EgyptAir");
                var aircraft = new Aircraft
                {
                    Model = "Model01",
                    Capacity = 180,
                    Airline = egyptAir
                };
                context.Aircrafts.Add(aircraft);
                context.SaveChanges();
                Console.WriteLine("   Aircraft Model01 added with ID: {0}\n", aircraft.Id);

                Console.WriteLine("   Adding crew for Model01");
                var crew = new Crew
                {
                    AircraftId = aircraft.Id,
                    MajorPilot = "Captain John Smith",
                    AssistantPilot = "First Officer Sarah Johnson",
                    Host1 = "Flight Attendant Mary Brown",
                    Host2 = "Flight Attendant David Wilson"
                };
                context.Crews.Add(crew);
                context.SaveChanges();
                Console.WriteLine("   Crew added for Aircraft Model01\n");

                Console.WriteLine("3. Recording transaction for EgyptAir");
                var transaction = new Transaction
                {
                    Amount = 50000,
                    Description = "Tickets",
                    Date = DateTime.Now,
                    Airline = egyptAir
                };
                context.Transactions.Add(transaction);
                context.SaveChanges();
                Console.WriteLine("   Transaction recorded with ID: {0}\n", transaction.Id);

                Console.WriteLine("Adding additional sample data");
                
                var employee1 = new Employee
                {
                    Name = "Mohamed Hassan",
                    Position = "Pilot",
                    Gender = "Male",
                    Address = "Cairo",
                    Qualifications = "Commercial Pilot License",
                    BirthdayYear = 1985,
                    BirthdayMonth = 5,
                    BirthdayDay = 15,
                    Airline = egyptAir
                };
                var employee2 = new Employee
                {
                    Name = "Fatima Ahmed",
                    Position = "Flight Attendant",
                    Gender = "Female",
                    Address = "Alexandria",
                    Qualifications = "Cabin Crew Training Certificate",
                    BirthdayYear = 1990,
                    BirthdayMonth = 8,
                    BirthdayDay = 22,
                    Airline = egyptAir
                };
                var employee3 = new Employee
                {
                    Name = "Omar Khalil",
                    Position = "Ground Staff",
                    Gender = "Male",
                    Address = "Giza",
                    Qualifications = "Airport Operations Certificate",
                    BirthdayYear = 1988,
                    BirthdayMonth = 3,
                    BirthdayDay = 10,
                    Airline = egyptAir
                };
                context.Employees.AddRange(employee1, employee2, employee3);
                context.SaveChanges();
                Console.WriteLine("   3 employees added\n");

                var oldTransaction1 = new Transaction
                {
                    Amount = 15000,
                    Description = "Maintenance",
                    Date = new DateTime(2018, 6, 15),
                    Airline = egyptAir
                };
                var oldTransaction2 = new Transaction
                {
                    Amount = 25000,
                    Description = "Fuel",
                    Date = new DateTime(2019, 3, 20),
                    Airline = egyptAir
                };
                context.Transactions.AddRange(oldTransaction1, oldTransaction2);
                context.SaveChanges();
                Console.WriteLine("   Old transactions added for testing\n");

                var emiratesAir = new Airline
                {
                    Name = "Emirates",
                    ContactPerson = "Abdullah Mohammed",
                    Address = "Dubai",
                    Phones = new List<string> { "0501234567" }
                };
                var emiratesEmployee = new Employee
                {
                    Name = "Ali Hassan",
                    Position = "Pilot",
                    Gender = "Male",
                    Address = "Dubai",
                    Airline = emiratesAir
                };
                context.Airlines.Add(emiratesAir);
                context.Employees.Add(emiratesEmployee);
                context.SaveChanges();
                Console.WriteLine("   Emirates airline added with 1 employee\n");

                Console.WriteLine("\nQUERY OPERATIONS\n");

                Console.WriteLine("4. Employees working in EgyptAir:");
                var egyptAirEmployees = context.Employees
                    .Include(e => e.Airline)
                    .Where(e => e.Airline!.Name == "EgyptAir")
                    .ToList();

                foreach (var emp in egyptAirEmployees)
                {
                    Console.WriteLine("   {0} (Position: {1}, Address: {2})", emp.Name, emp.Position, emp.Address);
                }
                Console.WriteLine();

                Console.WriteLine("5. Transactions recorded by EgyptAir:");
                var egyptAirTransactions = context.Transactions
                    .Include(t => t.Airline)
                    .Where(t => t.Airline!.Name == "EgyptAir")
                    .Select(t => new
                    {
                        t.Id,
                        t.Description,
                        t.Amount,
                        t.Date
                    })
                    .ToList();

                foreach (var trans in egyptAirTransactions)
                {
                    Console.WriteLine("   ID: {0}, Description: {1}, Amount: {2:C}, Date: {3:yyyy-MM-dd}", 
                        trans.Id, trans.Description, trans.Amount, trans.Date);
                }
                Console.WriteLine();

                Console.WriteLine("6. Total number of employees per airline:");
                var employeeCountByAirline = context.Airlines
                    .Select(a => new
                    {
                        AirlineName = a.Name,
                        EmployeeCount = a.Employees.Count
                    })
                    .ToList();

                foreach (var item in employeeCountByAirline)
                {
                    Console.WriteLine("   {0}: {1} employee(s)", item.AirlineName, item.EmployeeCount);
                }
                Console.WriteLine();

                Console.WriteLine("7. Updating capacity of Model01 aircraft to 200");
                var model01 = context.Aircrafts
                    .FirstOrDefault(a => a.Model == "Model01");

                if (model01 != null)
                {
                    Console.WriteLine("   Current capacity: {0}", model01.Capacity);
                    model01.Capacity = 200;
                    context.SaveChanges();
                    Console.WriteLine("   Updated capacity: {0}\n", model01.Capacity);
                }

                Console.WriteLine("8. Deleting transactions older than 2020");
                var oldTransactions = context.Transactions
                    .Where(t => t.Date.Year < 2020)
                    .ToList();

                Console.WriteLine("   Found {0} old transaction(s)", oldTransactions.Count);
                context.Transactions.RemoveRange(oldTransactions);
                context.SaveChanges();
                Console.WriteLine("   Deleted {0} transaction(s)\n", oldTransactions.Count);

                var remainingTransactions = context.Transactions.Count();
                Console.WriteLine("   Remaining transactions: {0}\n", remainingTransactions);

                Console.WriteLine("9. Inserting new route from Cairo to Dubai");
                var route = new Route
                {
                    Origin = "Cairo",
                    Destination = "Dubai",
                    Classification = "International",
                    Distance = 2400
                };
                context.Routes.Add(route);
                context.SaveChanges();
                Console.WriteLine("   Route added with ID: {0}\n", route.Id);

                Console.WriteLine("10. Assigning Model01 aircraft to Cairo-Dubai route");
                var model01Aircraft = context.Aircrafts
                    .FirstOrDefault(a => a.Model == "Model01");
                var cairoDubaiRoute = context.Routes
                    .FirstOrDefault(r => r.Origin == "Cairo" && r.Destination == "Dubai");

                if (model01Aircraft != null && cairoDubaiRoute != null)
                {
                    var aircraftRoute = new AircraftRoute
                    {
                        AircraftId = model01Aircraft.Id,
                        RouteId = cairoDubaiRoute.Id,
                        Duration = 4,
                        Price = 3000,
                        Departure = DateTime.Now.AddDays(1),
                        Arrival = DateTime.Now.AddDays(1).AddHours(4)
                    };
                    context.AircraftRoutes.Add(aircraftRoute);
                    context.SaveChanges();
                    Console.WriteLine("   Aircraft Model01 assigned to Cairo-Dubai route");
                    Console.WriteLine("   Duration: {0} hours", aircraftRoute.Duration);
                    Console.WriteLine("   Price: {0:C}\n", aircraftRoute.Price);
                }

                
                Console.WriteLine("\nFINAL DATABASE SUMMARY\n");
                Console.WriteLine("Total Airlines: {0}", context.Airlines.Count());
                Console.WriteLine("Total Employees: {0}", context.Employees.Count());
                Console.WriteLine("Total Aircraft: {0}", context.Aircrafts.Count());
                Console.WriteLine("Total Crews: {0}", context.Crews.Count());
                Console.WriteLine("Total Routes: {0}", context.Routes.Count());
                Console.WriteLine("Total Aircraft-Route Assignments: {0}", context.AircraftRoutes.Count());
                Console.WriteLine("Total Transactions: {0}", context.Transactions.Count());

                Console.WriteLine("\nRELATIONSHIP DEMONSTRATIONS\n");

                Console.WriteLine("One-to-One Relationship (Aircraft and Crew):");
                var aircraftWithCrew = context.Aircrafts
                    .Include(a => a.Crew)
                    .Include(a => a.Airline)
                    .FirstOrDefault(a => a.Model == "Model01");

                if (aircraftWithCrew != null)
                {
                    Console.WriteLine("  Aircraft: {0} (Capacity: {1})", aircraftWithCrew.Model, aircraftWithCrew.Capacity);
                    Console.WriteLine("  Airline: {0}", aircraftWithCrew.Airline?.Name);
                    if (aircraftWithCrew.Crew != null)
                    {
                        Console.WriteLine("  Crew:");
                        Console.WriteLine("    Major Pilot: {0}", aircraftWithCrew.Crew.MajorPilot);
                        Console.WriteLine("    Assistant Pilot: {0}", aircraftWithCrew.Crew.AssistantPilot);
                        Console.WriteLine("    Host 1: {0}", aircraftWithCrew.Crew.Host1);
                        Console.WriteLine("    Host 2: {0}", aircraftWithCrew.Crew.Host2);
                    }
                }
                Console.WriteLine();

                Console.WriteLine("One-to-Many Relationship (Airline to Employees):");
                var airlineWithEmployees = context.Airlines
                    .Include(a => a.Employees)
                    .FirstOrDefault(a => a.Name == "EgyptAir");

                if (airlineWithEmployees != null)
                {
                    Console.WriteLine("  Airline: {0}", airlineWithEmployees.Name);
                    Console.WriteLine("  Contact: {0}", airlineWithEmployees.ContactPerson);
                    Console.WriteLine("  Phones: {0}", string.Join(", ", airlineWithEmployees.Phones));
                    Console.WriteLine("  Employees ({0}):", airlineWithEmployees.Employees.Count);
                    foreach (var emp in airlineWithEmployees.Employees)
                    {
                        Console.WriteLine("    {0} ({1})", emp.Name, emp.Position);
                    }
                }
                Console.WriteLine();

                Console.WriteLine("Many-to-Many Relationship (Aircraft and Routes via AircraftRoute):");
                var aircraftWithRoutes = context.Aircrafts
                    .Include(a => a.AircraftRoutes)
                        .ThenInclude(ar => ar.Route)
                    .FirstOrDefault(a => a.Model == "Model01");

                if (aircraftWithRoutes != null)
                {
                    Console.WriteLine("  Aircraft: {0}", aircraftWithRoutes.Model);
                    Console.WriteLine("  Assigned Routes ({0}):", aircraftWithRoutes.AircraftRoutes.Count);
                    foreach (var ar in aircraftWithRoutes.AircraftRoutes)
                    {
                        Console.WriteLine("    {0} to {1}", ar.Route.Origin, ar.Route.Destination);
                        Console.WriteLine("    Classification: {0}", ar.Route.Classification);
                        Console.WriteLine("    Distance: {0} km", ar.Route.Distance);
                        Console.WriteLine("    Duration: {0} hours", ar.Duration);
                        Console.WriteLine("    Price: {0:C}", ar.Price);
                    }
                }
                Console.WriteLine();

                Console.WriteLine("\nAll operations completed successfully");
                Console.WriteLine("\nNote: Check RELATIONSHIPS_DOCUMENTATION.md for detailed explanation");
                Console.WriteLine("of how each relationship is implemented using Convention, Data Annotations,");
                Console.WriteLine("and Fluent API\n");
            }

            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }
    }
}
