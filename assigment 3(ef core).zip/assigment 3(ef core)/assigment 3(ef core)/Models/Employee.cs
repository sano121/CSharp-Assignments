using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace assigment_3_ef_core_.Models
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [MaxLength(100)]
        public string? Position { get; set; }

        [MaxLength(10)]
        public string? Gender { get; set; }

        [MaxLength(500)]
        public string? Address { get; set; }

        [MaxLength(500)]
        public string? Qualifications { get; set; }

        // Birthday composite attributes
        public int? BirthdayYear { get; set; }
        public int? BirthdayMonth { get; set; }
        public int? BirthdayDay { get; set; }

        // Foreign Key for Airline (Many-to-One Optional)
        public int? AirlineId { get; set; }

        // Navigation Property
        [ForeignKey("AirlineId")]
        public virtual Airline? Airline { get; set; }
    }
}
