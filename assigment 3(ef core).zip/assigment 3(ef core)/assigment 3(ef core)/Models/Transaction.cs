using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace assigment_3_ef_core_.Models
{
    public class Transaction
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(500)]
        public string? Description { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Amount { get; set; }

        public DateTime Date { get; set; }

        // Foreign Key for Airline (Many-to-One Optional)
        public int? AirlineId { get; set; }

        // Navigation Property
        [ForeignKey("AirlineId")]
        [InverseProperty("Transactions")]
        public virtual Airline? Airline { get; set; }
    }
}
