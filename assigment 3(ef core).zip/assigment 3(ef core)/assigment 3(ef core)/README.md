# EF Core Assignment 3 - Airline Management System

## Project Overview
This project is a comprehensive Entity Framework Core implementation of an airline management system with various types of relationships between entities.

## Database Schema

### Entities
1. **Airline** - Represents airline companies
2. **Employee** - Airline employees
3. **Transaction** - Financial transactions recorded by airlines
4. **Aircraft** - Airplanes owned by airlines
5. **Crew** - Flight crew assigned to aircraft
6. **Route** - Flight routes
7. **AircraftRoute** - Join table for many-to-many relationship between Aircraft and Routes

## Relationships Implemented

### 1. One-to-One (Required from both sides)
- **Aircraft ? Crew**
- Each aircraft must have exactly one crew
- Each crew must belong to exactly one aircraft
- Implemented using: Convention, Data Annotations, and Fluent API

### 2. One-to-Many (Optional from both sides)
- **Airline ? Employees**
- **Airline ? Transactions**
- **Airline ? Aircraft**
- Each airline can have multiple employees/transactions/aircraft
- Each employee/transaction/aircraft can optionally belong to one airline
- Implemented using: Convention, Data Annotations, and Fluent API

### 3. Many-to-Many
- **Aircraft ? Routes**
- Many aircraft can be assigned to many routes
- Implemented with explicit join entity (AircraftRoute) containing additional properties:
  - Duration
  - Price
  - Arrival
  - Departure
  - NumOfPassengers
- Implemented using: Data Annotations and Fluent API

## Complex Types

### Phones (in Airline)
Stored as a collection (List<string>) representing multiple phone numbers

### Birthday (in Employee)
Broken down into composite attributes:
- BirthdayYear
- BirthdayMonth
- BirthdayDay

## CRUD Operations Implemented

### Create (Insert)
1. ? Insert airline "EgyptAir" with contact person, phones, and address
2. ? Add aircraft "Model01" with capacity 180 and airline "EgyptAir"
3. ? Record transaction of 50000 with description "Tickets" for "EgyptAir"
4. ? Insert route from "Cairo" to "Dubai", classification "International", distance 2400 km
5. ? Assign "Model01" aircraft to Cairo-Dubai route with duration 4 hours and price 3000 LE

### Read (Select)
1. ? Select all employees who work in "EgyptAir"
2. ? Show all transactions (id, description, amount) recorded by "EgyptAir"
3. ? Get total number of employees working in each airline

### Update
1. ? Change the capacity of "Model01" aircraft to 200

### Delete
1. ? Delete all transactions older than 2020

## Project Structure

```
assigment 3(ef core)/
??? Models/
?   ??? Airline.cs
?   ??? Employee.cs
?   ??? Transaction.cs
?   ??? Aircraft.cs
?   ??? Crew.cs
?   ??? Route.cs
?   ??? AircraftRoute.cs
??? Data/
?   ??? AirlineDbContext.cs
??? Program.cs
??? RELATIONSHIPS_DOCUMENTATION.md
??? README.md
```

## How to Run

1. **Prerequisites**
   - .NET 9.0 SDK
   - SQL Server LocalDB (or update connection string in `AirlineDbContext.cs`)

2. **Build the project**
   ```bash
   dotnet build
   ```

3. **Run the application**
   ```bash
   dotnet run
   ```

4. **Database**
   - The application will automatically create the database on first run
   - Database name: `AirlineDb`
   - Connection: SQL Server LocalDB

## Implementation Details

### Convention-Based Relationships
EF Core can automatically detect relationships based on:
- Navigation properties
- Foreign key naming conventions
- Collection properties

### Data Annotations
Used for:
- Primary keys (`[Key]`)
- Required fields (`[Required]`)
- String lengths (`[MaxLength]`)
- Foreign keys (`[ForeignKey]`)
- Inverse properties (`[InverseProperty]`)
- Column types (`[Column]`)

### Fluent API
Configured in `OnModelCreating` method:
- Complex relationships
- Delete behaviors (Cascade, SetNull)
- Unique constraints
- Precise column configurations
- Composite indexes

## Key Features

1. **Comprehensive Relationship Coverage**
   - One-to-One (required)
   - One-to-Many (optional)
   - Many-to-Many (with payload)

2. **Three Implementation Methods**
   - Convention
   - Data Annotations
   - Fluent API

3. **InverseProperty Usage**
   - Applied where multiple relationships exist between same entities
   - Clarifies navigation property mappings

4. **Complex Types**
   - Phone collection
   - Composite birthday attributes

5. **Complete CRUD Operations**
   - All required operations implemented and demonstrated

## Documentation

See `RELATIONSHIPS_DOCUMENTATION.md` for detailed analysis of each relationship type, including:
- Can EF Core derive it by convention?
- Can it be implemented using Data Annotations?
- How to implement using Fluent API?
- When to use InverseProperty?

## Technologies Used

- .NET 9.0
- Entity Framework Core 9.0
- SQL Server
- C# 13.0

## Author Notes

This project demonstrates:
- ? All three relationship types (1-to-1, 1-to-M, M-to-M)
- ? Required and optional relationships
- ? Three implementation approaches for each relationship
- ? InverseProperty usage where applicable
- ? Complete CRUD operations
- ? Complex types and composite attributes
- ? Best practices for EF Core development

## Testing the Application

When you run the application, it will:
1. Create a fresh database
2. Insert sample data (airlines, employees, aircraft, routes, etc.)
3. Execute all required CRUD operations
4. Display results in the console
5. Show relationship demonstrations

The console output includes:
- Confirmation of each operation
- Query results
- Database summary
- Relationship demonstrations

## Connection String

Default connection string (in `AirlineDbContext.cs`):
```csharp
Server=(localdb)\\mssqllocaldb;Database=AirlineDb;Trusted_Connection=True;MultipleActiveResultSets=true
```

To use a different SQL Server instance, update this connection string.

## Notes

- The application uses `EnsureDeleted()` and `EnsureCreated()` for demonstration purposes
- In production, use EF Core Migrations instead
- Virtual navigation properties enable lazy loading (if configured)
- The project follows EF Core best practices and conventions

---

**Assignment Completed**: All requirements met with comprehensive documentation and working code.
