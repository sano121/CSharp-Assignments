﻿namespace assigment_3_c_;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("type number ");
        int s = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine($"ypur number is {s}");
        String str = "arsany";
        int number = 123;
        int numb2 = int.Parse(str);//it cant conver a string into int
        int numb3 = Convert.ToInt32(str);//it cant conver a string into int
        float f = 12.79f;
        float f2 = 13.8f;
        Console.WriteLine($"the sum of {f} and {f2} is {f + f2}");//it will be rounded

        String orig = "arsany";
        String orig2 = orig.Substring(0);

        int x = 5;
        int y = x;//y=5
        y = 12;//y=12 the new and last value 

        Person p1 = new Person { Name = "Ali" };
        Person p2 = p1;
        p2.Name = "Omar";


        string s1 = "arsany ";
        string s2 = "refaat";
        string result = s1 + s2;
        Console.WriteLine(result);


        Console.Write("Enter principal: ");
        double principal = double.Parse(Console.ReadLine());

        Console.Write("Enter rate: ");
        double rate = double.Parse(Console.ReadLine());

        Console.Write("Enter time: ");
        double time = double.Parse(Console.ReadLine());

        double interest = (principal * rate * time) / 100;
        Console.WriteLine("Simple Interest = " + interest);


        Console.Write("Enter weight (kg): ");
        double? weight = double.Parse(Console.ReadLine());

        Console.Write("Enter height (m): ");
        double? height = double.Parse(Console.ReadLine());

        double? bmi = weight / (height * height);
        Console.WriteLine("BMI = " + bmi);

        Console.WriteLine("enter your temp");
        double temp = double.Parse(Console.ReadLine());
        String result2 = temp < 10 ? "Just Cold"
                      : temp > 30 ? "Just Hot"
                      : "Just Good";

        Console.Write("Enter day: ");
        int day = Convert.ToInt32(Console.ReadLine);
        Console.Write("Enter month: ");
        int month = int.Parse(Console.ReadLine());

        Console.Write("Enter year: ");
        int year = int.Parse(Console.ReadLine());

        Console.WriteLine($"Today's date : {day}, {month}, {year}");
        Console.WriteLine($"Today's date : {day}/{month}/{year}");
        Console.WriteLine($"Today's date : {day}-{month}-{year}");

        Console.Write("Enter number: ");
        int num = int.Parse(Console.ReadLine());

        if (num % 3 == 0 && num % 4 == 0)
            Console.WriteLine("Yes");
        else
            Console.WriteLine("No");



        Console.Write("Enter number: ");
        int num3 = int.Parse(Console.ReadLine());

        if (num3 < 0)
            Console.WriteLine("Negative");
        else
            Console.WriteLine("Positive");


        Console.Write("Enter first number: ");
        int a = int.Parse(Console.ReadLine());

        Console.Write("Enter second number: ");
        int b = int.Parse(Console.ReadLine());

        Console.Write("Enter third number: ");
        int c = int.Parse(Console.ReadLine());

        int max = Math.Max(a, Math.Max(b, c));
        int min = Math.Min(a, Math.Min(b, c));

        Console.WriteLine("Max = " + max);
        Console.WriteLine("Min = " + min);



        Console.Write("Enter number: ");
        int numiseven = int.Parse(Console.ReadLine());

        if (numiseven % 2 == 0)
            Console.WriteLine("Even");
        else
            Console.WriteLine("Odd");



        Console.Write("Enter character: ");
        char ch = char.ToLower(Console.ReadKey().KeyChar);
        Console.WriteLine();

        if ("aeiou".Contains(ch))
            Console.WriteLine("Vowel");
        else
            Console.WriteLine("Consonant");

        Console.Write("Enter month number (1-12): ");
        int monthm = int.Parse(Console.ReadLine());

        int days = DateTime.DaysInMonth(2025, monthm);
        Console.WriteLine("Days in month: " + days);

        Console.Write("Enter age: ");
        int age = int.Parse(Console.ReadLine());
        Console.Write("Enter day of week: ");
        string dayName = Console.ReadLine();
        double ticket = 100;
        if (age < 12)
            ticket *= 0.5;
        else if (age > 60)
            ticket *= 0.7;
        if (dayName.ToLower() == "friday" || dayName.ToLower() == "saturday")
            ticket += 20;
        Console.WriteLine("Final ticket price = " + ticket + " EGP");

        Console.Write("Enter units consumed: ");
        int units = int.Parse(Console.ReadLine());
        double bill = 0;
        if (units <= 100)
            bill = units * 0.5;
        else if (units <= 200)
            bill = 100 * 0.5 + (units - 100) * 0.75;
        else
            bill = 100 * 0.5 + 100 * 0.75 + (units - 200) * 1;
        if (bill > 500)
            bill += bill * 0.1;
        Console.WriteLine("Total bill = " + bill);

        Console.Write("Enter role (Manager/Developer/Intern): ");
        string role = Console.ReadLine();
        Console.Write("Enter years of experience: ");
        int exp = int.Parse(Console.ReadLine());
        Console.Write("Enter base salary: ");
        double salary = double.Parse(Console.ReadLine());
        double bonus = 0;

        if (role.ToLower() is "manager")
            bonus = exp > 10 ? salary * 0.2 : salary * 0.15;
        else if (role.ToLower() is "developer")
            bonus = exp > 5 ? salary * 0.12 : salary * 0.08;
        else if (role.ToLower() is "intern")
            bonus = salary * 0.05;

        double finalSalary = salary + bonus;
        Console.WriteLine($"Role: {role}, Exp: {exp}, Salary: {salary}, Bonus: {bonus}, Final = {finalSalary}");

        Console.Write("Enter grade (A,B,C,D,F): ");
        char grade = char.ToUpper(Console.ReadKey().KeyChar);
        Console.WriteLine();
        switch (grade)
        {
            case 'A':
                Console.WriteLine("Excellent, GPA=4.0, Eligible for Scholarship");
                break;
            case 'B':
                Console.WriteLine("Very Good, GPA=3.0, Eligible for Scholarship");
                break;
            case 'C':
                Console.WriteLine("Good, GPA=2.0, Not Eligible for Scholarship");
                break;
            case 'D':
                Console.WriteLine("Pass, GPA=1.0, Not Eligible for Scholarship");
                break;
            case 'F':
                Console.WriteLine("Fail, GPA=0.0, Not Eligible for Scholarship");
                break;
            default:
                Console.WriteLine("Invalid grade");
                break;
        }
    }
    class Person
    {
        public string Name;
    }
}
