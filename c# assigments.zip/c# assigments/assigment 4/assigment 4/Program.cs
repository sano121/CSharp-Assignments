﻿using System.IO.Compression;

namespace assigment_4;

class Program
{
    static void Main(string[] args)
    {functions functions = new functions();
        
        functions.print();
        Console.WriteLine();
        functions.Multiplication_table();
        Console.WriteLine();
        functions.Even_numbers();
        Console.WriteLine();
        functions.Power_calculation();
        Console.WriteLine();
        functions.Marks_of_5_subjects();
        Console.WriteLine();
        functions.Reverse_string();
        Console.WriteLine();
        functions.Reverse_integer();
        Console.WriteLine();
        functions.Prime_numbers_in_range();
        Console.WriteLine();
        functions.Decimal_to_binary();
        Console.WriteLine();
        functions.Check_if_3_points_are_collinear();
        Console.WriteLine();
        functions.Identity_matrix();
        Console.WriteLine();
        functions.Sum_of_array();
        Console.WriteLine();
        functions.Frequency_of_elements();
        Console.WriteLine();
        functions.Max_and_Min();
        Console.WriteLine();
        functions.Second_largest();
        Console.WriteLine();
        functions.Longest_distance();
        Console.WriteLine();
        functions.Reverse_words();
        Console.WriteLine();
        functions.Copy_2D_array();
    }
    class functions
    {
        public void print()
        {
            Console.Write("Enter a number: ");
            int n = int.Parse(Console.ReadLine());
            for (int i = 1; i <= n; i++)
                Console.Write(i + " ");
        }

        public void Multiplication_table()
        {
            Console.Write("Enter a number: ");
            int n = int.Parse(Console.ReadLine());
            for (int i = 1; i <= 12; i++)
                Console.Write(n * i + " ");
        }

        public void Even_numbers()
        {
            Console.Write("Enter a number: ");
            int n = int.Parse(Console.ReadLine());
            for (int i = 2; i <= n; i += 2)
                Console.Write(i + " ");
        }

        public void Power_calculation()
        {
            Console.Write("Enter base: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("Enter exponent: ");
            int b = int.Parse(Console.ReadLine());

            int result = 1;
            for (int i = 1; i <= b; i++)
                result *= a;

            Console.WriteLine($"Result = {result}");
        }

        public void Marks_of_5_subjects()
        {
            int total = 0;
            Console.WriteLine("Enter marks of 5 subjects:");
            for (int i = 0; i < 5; i++)
                total += int.Parse(Console.ReadLine());

            double average = total / 5.0;
            double percentage = (total / 500.0) * 100;

            Console.WriteLine($"Total = {total}");
            Console.WriteLine($"Average = {average}");
            Console.WriteLine($"Percentage = {percentage}");
        }

        public void Reverse_string()
        {
            Console.Write("Enter a string: ");
            string s = Console.ReadLine();
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            Console.WriteLine(new string(arr));
        }

        public void Reverse_integer()
        {
            Console.Write("Enter a number: ");
            int n = int.Parse(Console.ReadLine());
            int rev = 0;
            while (n > 0)
            {
                rev = rev * 10 + (n % 10);
                n /= 10;
            }
            Console.WriteLine($"Reversed = {rev}");
        }

        public void Prime_numbers_in_range()
        {
            Console.Write("Enter start: ");
            int start = int.Parse(Console.ReadLine());
            Console.Write("Enter end: ");
            int end = int.Parse(Console.ReadLine());

            Console.WriteLine("Primes are: ");
            for (int i = start; i <= end; i++)
            {
                if (i < 2) continue;
                bool prime = true;
                for (int j = 2; j * j <= i; j++)
                    if (i % j == 0) { prime = false; break; }
                if (prime) Console.Write(i + " ");
            }
        }

        public void Decimal_to_binary()
        {
            Console.Write("Enter a number: ");
            int n = int.Parse(Console.ReadLine());
            string binary = "";
            while (n > 0)
            {
                binary = (n % 2) + binary;
                n /= 2;
            }
            Console.WriteLine("Binary: " + binary);
        }

        public void Check_if_3_points_are_collinear()
        {
            Console.Write("Enter x1 y1: ");
            int x1 = int.Parse(Console.ReadLine());
            int y1 = int.Parse(Console.ReadLine());

            Console.Write("Enter x2 y2: ");
            int x2 = int.Parse(Console.ReadLine());
            int y2 = int.Parse(Console.ReadLine());

            Console.Write("Enter x3 y3: ");
            int x3 = int.Parse(Console.ReadLine());
            int y3 = int.Parse(Console.ReadLine());

            int area = x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2);

            if (area == 0) Console.WriteLine("Points are collinear.");
            else Console.WriteLine("Not collinear.");
        }

        public static void Identity_matrix()
        {
            Console.Write("Enter size: ");
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                    Console.Write((i == j ? 1 : 0) + " ");
                Console.WriteLine();
            }
        }

        public static void Sum_of_array()
        {
            Console.Write("Enter size: ");
            int n = int.Parse(Console.ReadLine());
            int[] arr = new int[n];
            int sum = 0;

            Console.WriteLine("Enter elements:");
            for (int i = 0; i < n; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
                sum += arr[i];
            }

            Console.WriteLine("Sum = " + sum);
        }

        static void Merge_2_arrays_and_sort()
        {
            Console.Write("Enter size: ");
            int n = int.Parse(Console.ReadLine());

            int[] a = new int[n];
            int[] b = new int[n];

            Console.WriteLine("Enter first array:");
            for (int i = 0; i < n; i++) a[i] = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter second array:");
            for (int i = 0; i < n; i++) b[i] = int.Parse(Console.ReadLine());

            int[] merged = new int[2 * n];
            a.CopyTo(merged, 0);
            b.CopyTo(merged, n);

            Array.Sort(merged);

            Console.WriteLine("Merged array:");
            foreach (int x in merged) Console.Write(x + " ");
        }

        public static void Frequency_of_elements()
        {
            Console.Write("Enter size: ");
            int n = int.Parse(Console.ReadLine());
            int[] arr = new int[n];

            Console.WriteLine("Enter elements:");
            for (int i = 0; i < n; i++) arr[i] = int.Parse(Console.ReadLine());

            bool[] visited = new bool[n];

            for (int i = 0; i < n; i++)
            {
                if (visited[i]) continue;
                int count = 1;
                for (int j = i + 1; j < n; j++)
                {
                    if (arr[i] == arr[j])
                    {
                        count++;
                        visited[j] = true;
                    }
                }
                Console.WriteLine($"{arr[i]} occurs {count} times");
            }
        }

        public static void Max_and_Min()
        {
            Console.Write("Enter size: ");
            int n = int.Parse(Console.ReadLine());
            int[] arr = new int[n];

            Console.WriteLine("Enter elements:");
            for (int i = 0; i < n; i++) arr[i] = int.Parse(Console.ReadLine());

            int max = arr[0], min = arr[0];
            foreach (int x in arr)
            {
                if (x > max) max = x;
                if (x < min) min = x;
            }

            Console.WriteLine($"Max = {max}, Min = {min}");
        }

        public static void Second_largest()
        {
            Console.Write("Enter size: ");
            int n = int.Parse(Console.ReadLine());
            int[] arr = new int[n];

            Console.WriteLine("Enter elements:");
            for (int i = 0; i < n; i++) arr[i] = int.Parse(Console.ReadLine());

            Array.Sort(arr);
            Console.WriteLine("Second largest = " + arr[n - 2]);
        }


        public static void Longest_distance()
        {
            Console.Write("Enter size: ");
            int n = int.Parse(Console.ReadLine());
            int[] arr = new int[n];

            Console.WriteLine("Enter elements:");
            for (int i = 0; i < n; i++) arr[i] = int.Parse(Console.ReadLine());

            int longest = 0;
            for (int i = 0; i < n; i++)
            {
                for (int j = i + 1; j < n; j++)
                {
                    if (arr[i] == arr[j])
                    {
                        int distance = j - i - 1;
                        if (distance > longest)
                            longest = distance;
                    }
                }
            }
            Console.WriteLine("Longest distance = " + longest);
        }

        public static void Reverse_words()
        {
            Console.Write("Enter a sentence: ");
            string input = Console.ReadLine();
            string[] words = input.Split(' ');
            Array.Reverse(words);
            Console.WriteLine(string.Join(" ", words));
        }


        public static void Copy_2D_array()
        {
            Console.Write("Enter rows: ");
            int r = int.Parse(Console.ReadLine());
            Console.Write("Enter cols: ");
            int c = int.Parse(Console.ReadLine());

            int[,] arr1 = new int[r, c];
            int[,] arr2 = new int[r, c];

            Console.WriteLine("Enter elements:");
            for (int i = 0; i < r; i++)
                for (int j = 0; j < c; j++)
                    arr1[i, j] = int.Parse(Console.ReadLine());

            // Copy
            for (int i = 0; i < r; i++)
                for (int j = 0; j < c; j++)
                    arr2[i, j] = arr1[i, j];

            Console.WriteLine("Copied array:");
            for (int i = 0; i < r; i++)
            {
                for (int j = 0; j < c; j++)
                    Console.Write(arr2[i, j] + " ");
                Console.WriteLine();

            }
        }
    }
}
