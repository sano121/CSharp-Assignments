# EF Core Relationship Implementation Documentation

## Overview
This project implements a complete airline management system with various types of relationships as required in the assignment.

---

## Relationship Analysis

### 1. ONE-TO-ONE RELATIONSHIP: Aircraft <-> Crew (Required from both sides)

**Entities:** `Aircraft` and `Crew`

#### 1. Can EF Core derive it by convention?
**Answer:** YES, partially. EF Core can detect a one-to-one relationship by convention if:
- One entity has a navigation property to another
- The other entity has a navigation property back
- One entity has a foreign key property

However, EF Core needs explicit configuration to make it **required from both sides** (cascade delete).

#### 2. Can implement it using Data Annotation?
**Answer:** YES

**Implementation in Code:**
```csharp
// In Crew.cs
public class Crew
{
    [Key]
    public int Id { get; set; }
    
    [Required]  // Makes the relationship required from Crew side
    public int AircraftId { get; set; }
    
    [ForeignKey("AircraftId")]
    public virtual Aircraft Aircraft { get; set; } = null!;
}

// In Aircraft.cs
public class Aircraft
{
    [Key]
    public int Id { get; set; }
    
    public virtual Crew? Crew { get; set; }
}
```

**Explanation:**
- `[Required]` on `AircraftId` makes the relationship required from the Crew side
- `[ForeignKey("AircraftId")]` specifies which property is the FK
- The navigation properties establish the one-to-one relationship

#### 3. Fluent API Implementation
**Answer:** YES - Best practice for complex relationships

**Implementation in DbContext:**
```csharp
modelBuilder.Entity<Aircraft>(entity =>
{
    entity.HasOne(a => a.Crew)
        .WithOne(c => c.Aircraft)
        .HasForeignKey<Crew>(c => c.AircraftId)
        .OnDelete(DeleteBehavior.Cascade); // Required from both sides
});
```

**Explanation:**
- `HasOne().WithOne()` defines the one-to-one relationship
- `HasForeignKey<Crew>()` specifies which entity contains the foreign key
- `OnDelete(DeleteBehavior.Cascade)` enforces the required relationship (if Aircraft is deleted, Crew is deleted)

#### 4. InverseProperty Usage
**Answer:** NOT REQUIRED for this simple one-to-one relationship, but can be used:
```csharp
[InverseProperty("Aircraft")]
public virtual Crew? Crew { get; set; }
```

---

### 2. ONE-TO-MANY RELATIONSHIP: Airline -> Employees (Optional from both sides)

**Entities:** `Airline` (One) and `Employee` (Many)

#### 1. Can EF Core derive it by convention?
**Answer:** YES. EF Core automatically detects one-to-many relationships when:
- One entity has a collection navigation property
- The other entity has a reference navigation property
- A foreign key property exists (or EF Core will shadow one)

By convention, EF Core makes the relationship optional unless the FK is non-nullable.

#### 2. Can implement it using Data Annotation?
**Answer:** YES

**Implementation in Code:**
```csharp
// In Employee.cs
public class Employee
{
    [Key]
    public int Id { get; set; }
    
    public int? AirlineId { get; set; }  // Nullable = Optional
    
    [ForeignKey("AirlineId")]
    public virtual Airline? Airline { get; set; }
}

// In Airline.cs
public class Airline
{
    [Key]
    public int Id { get; set; }
    
    public virtual ICollection<Employee> Employees { get; set; } = new List<Employee>();
}
```

**Explanation:**
- Nullable `int?` for `AirlineId` makes the relationship optional
- `[ForeignKey]` attribute explicitly specifies the FK property
- Collection navigation property in Airline represents the "many" side

#### 3. Fluent API Implementation
**Answer:** YES

**Implementation in DbContext:**
```csharp
modelBuilder.Entity<Airline>(entity =>
{
    entity.HasMany(a => a.Employees)
        .WithOne(e => e.Airline)
        .HasForeignKey(e => e.AirlineId)
        .OnDelete(DeleteBehavior.SetNull); // Optional relationship
});
```

**Explanation:**
- `HasMany().WithOne()` defines the one-to-many relationship
- `HasForeignKey()` specifies the FK property
- `OnDelete(DeleteBehavior.SetNull)` makes it optional (FK set to null on delete)

#### 4. InverseProperty Usage
**Answer:** NOT REQUIRED for this relationship, but useful if there are multiple relationships between same entities.

---

### 3. ONE-TO-MANY RELATIONSHIP: Airline -> Transactions (Optional from both sides)

**Entities:** `Airline` (One) and `Transaction` (Many)

#### 1. Can EF Core derive it by convention?
**Answer:** YES (same as Airline -> Employees)

#### 2. Can implement it using Data Annotation?
**Answer:** YES

**Implementation in Code:**
```csharp
// In Transaction.cs
public class Transaction
{
    [Key]
    public int Id { get; set; }
    
    public int? AirlineId { get; set; }
    
    [ForeignKey("AirlineId")]
    [InverseProperty("Transactions")]  // Used because Airline has multiple collections
    public virtual Airline? Airline { get; set; }
}

// In Airline.cs
public class Airline
{
    [InverseProperty("Airline")]
    public virtual ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();
}
```

#### 3. Fluent API Implementation
**Answer:** YES

**Implementation in DbContext:**
```csharp
modelBuilder.Entity<Airline>(entity =>
{
    entity.HasMany(a => a.Transactions)
        .WithOne(t => t.Airline)
        .HasForeignKey(t => t.AirlineId)
        .OnDelete(DeleteBehavior.SetNull);
});
```

#### 4. InverseProperty Usage
**Answer:** RECOMMENDED because Airline has multiple collection navigation properties (Employees, Transactions, Aircrafts)

---

### 4. ONE-TO-MANY RELATIONSHIP: Airline -> Aircraft (Optional from both sides)

**Entities:** `Airline` (One) and `Aircraft` (Many)

#### 1-4: Same implementation pattern as Airline -> Employees

---

### 5. MANY-TO-MANY RELATIONSHIP: Aircraft <-> Route

**Entities:** `Aircraft` and `Route` with join entity `AircraftRoute`

#### 1. Can EF Core derive it by convention?
**Answer:** PARTIALLY. EF Core 5+ can automatically create a join table for many-to-many relationships using convention:
```csharp
public class Aircraft
{
    public ICollection<Route> Routes { get; set; }
}
public class Route
{
    public ICollection<Aircraft> Aircrafts { get; set; }
}
```

However, since we need additional properties (Duration, Price, NumOfPassengers, Arrival, Departure), we MUST use an **explicit join entity** (`AircraftRoute`). EF Core cannot derive this by convention alone.

#### 2. Can implement it using Data Annotation?
**Answer:** YES, with explicit join entity

**Implementation in Code:**
```csharp
// In AircraftRoute.cs (Join Entity)
public class AircraftRoute
{
    [Key]
    public int Id { get; set; }
    
    [Required]
    public int AircraftId { get; set; }
    
    [Required]
    public int RouteId { get; set; }
    
    // Additional properties
    public int? Duration { get; set; }
    public decimal? Price { get; set; }
    
    [ForeignKey("AircraftId")]
    public virtual Aircraft Aircraft { get; set; } = null!;
    
    [ForeignKey("RouteId")]
    public virtual Route Route { get; set; } = null!;
}

// In Aircraft.cs
public class Aircraft
{
    public virtual ICollection<AircraftRoute> AircraftRoutes { get; set; }
}

// In Route.cs
public class Route
{
    public virtual ICollection<AircraftRoute> AircraftRoutes { get; set; }
}
```

#### 3. Fluent API Implementation
**Answer:** YES - Recommended approach

**Implementation in DbContext:**
```csharp
modelBuilder.Entity<AircraftRoute>(entity =>
{
    entity.HasKey(ar => ar.Id);
    
    entity.HasOne(ar => ar.Aircraft)
        .WithMany(a => a.AircraftRoutes)
        .HasForeignKey(ar => ar.AircraftId)
        .OnDelete(DeleteBehavior.Cascade);
    
    entity.HasOne(ar => ar.Route)
        .WithMany(r => r.AircraftRoutes)
        .HasForeignKey(ar => ar.RouteId)
        .OnDelete(DeleteBehavior.Cascade);
    
    // Prevent duplicate assignments
    entity.HasIndex(ar => new { ar.AircraftId, ar.RouteId })
        .IsUnique();
});
```

**Explanation:**
- Explicit join entity with its own primary key
- Two one-to-many relationships form the many-to-many
- Composite unique index prevents duplicate aircraft-route assignments
- Cascade delete removes join records when either Aircraft or Route is deleted

#### 4. InverseProperty Usage
**Answer:** NOT REQUIRED for this pattern, as the join entity clearly defines the relationships

---

## Summary Table

| Relationship Type | Entities | EF Convention? | Data Annotations? | Fluent API? | InverseProperty? |
|------------------|----------|----------------|-------------------|-------------|------------------|
| One-to-One (Required) | Aircraft <-> Crew | Partial | ? Yes | ? Yes (Best) | Optional |
| One-to-Many (Optional) | Airline -> Employees | ? Yes | ? Yes | ? Yes | Optional |
| One-to-Many (Optional) | Airline -> Transactions | ? Yes | ? Yes | ? Yes | ? Recommended |
| One-to-Many (Optional) | Airline -> Aircraft | ? Yes | ? Yes | ? Yes | Optional |
| Many-to-Many | Aircraft <-> Route | No (needs props) | ? Yes | ? Yes (Best) | No |

---

## Complex Types

### Phones in Airline Entity
The `Phones` property is implemented as a collection (List<string>) and stored as JSON in the database:
```csharp
public List<string> Phones { get; set; } = new List<string>();
```

### Birthday in Employee Entity
Birthday is broken down into composite attributes:
```csharp
public int? BirthdayYear { get; set; }
public int? BirthdayMonth { get; set; }
public int? BirthdayDay { get; set; }
```

---

## Best Practices Implemented

1. **Fluent API for complex relationships** - Most reliable and maintainable
2. **Data Annotations for simple constraints** - Good for basic validation
3. **InverseProperty when needed** - Clarifies multiple relationships between same entities
4. **Explicit join entities** - For many-to-many with additional properties
5. **Optional vs Required** - Properly configured with nullable types and delete behaviors
6. **Virtual navigation properties** - Enables lazy loading (if configured)
